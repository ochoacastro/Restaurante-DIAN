require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const { emitirFactura, emitirNotaCredito, consultarEstado } = require('./dian');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '2mb' }));

// ── Ping ──────────────────────────────────────────────────────────────
app.get('/ping', (req, res) => {
  res.json({
    ok: true,
    servicio: 'FE Helechos Backend',
    ambiente: process.env.DIAN_AMBIENTE === 'produccion' ? 'PRODUCCIÓN' : 'PRUEBAS',
    version: '1.1.0',
    ts: new Date().toISOString()
  });
});

// ── Emitir factura electrónica ────────────────────────────────────────
app.post('/emitir-factura', async (req, res) => {
  try {
    const payload = req.body;
    if (!payload?.factura?.numero)        return res.status(400).json({ error: 'Falta factura.numero' });
    if (!payload?.emisor?.nit)            return res.status(400).json({ error: 'Falta emisor.nit' });
    if (!payload?.factura?.items?.length) return res.status(400).json({ error: 'Factura sin items' });
    const resultado = await emitirFactura(payload);
    res.json(resultado);
  } catch (err) {
    console.error('[/emitir-factura]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── Consultar estado por CUFE ─────────────────────────────────────────
app.get('/estado/:cufe', async (req, res) => {
  try {
    const estado = await consultarEstado(req.params.cufe);
    res.json(estado);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Nota crédito (anulación) ──────────────────────────────────────────
app.post('/nota-credito', async (req, res) => {
  try {
    if (!req.body?.facturaOriginal?.cufe) return res.status(400).json({ error: 'Falta facturaOriginal.cufe' });
    const resultado = await emitirNotaCredito(req.body);
    res.json(resultado);
  } catch (err) {
    console.error('[/nota-credito]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── Nota débito (cargo adicional) ─────────────────────────────────────
app.post('/nota-debito', async (req, res) => {
  try {
    if (!req.body?.facturaReferencia?.cufe) return res.status(400).json({ error: 'Falta facturaReferencia.cufe' });
    if (!req.body?.valor || req.body.valor <= 0) return res.status(400).json({ error: 'Falta valor > 0' });
    const { emitirNotaDebito } = require('./dian');
    const resultado = await emitirNotaDebito(req.body);
    res.json(resultado);
  } catch (err) {
    console.error('[/nota-debito]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── Reenviar email con CUFE ───────────────────────────────────────────
app.post('/reenviar-email', async (req, res) => {
  try {
    const { cufe, correo, nombre, numero, total, fecha } = req.body;
    if (!correo) return res.status(400).json({ error: 'Falta correo' });
    if (!cufe)   return res.status(400).json({ error: 'Falta cufe' });

    // Usar nodemailer si está configurado, de lo contrario retornar instrucciones
    const nodemailer = (() => { try { return require('nodemailer'); } catch(e) { return null; } })();
    if (!nodemailer || !process.env.SMTP_HOST) {
      // Sin SMTP configurado: devolver ok=false con instrucciones
      return res.json({
        ok: false,
        error: 'SMTP no configurado. Agrega SMTP_HOST, SMTP_USER, SMTP_PASS en las variables de entorno de Railway.'
      });
    }

    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: process.env.SMTP_PORT === '465',
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });

    await transporter.sendMail({
      from: `"${config.nombre || 'Restaurante'}" <${process.env.SMTP_USER}>`,
      to: correo,
      subject: `Factura Electrónica #${numero}`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:500px;">
          <h2>Factura Electrónica</h2>
          <p>Estimado/a <strong>${nombre}</strong>,</p>
          <p>Adjunto encontrará su factura electrónica #<strong>${numero}</strong> por valor de <strong>$${Number(total).toLocaleString('es-CO')}</strong> del ${fecha}.</p>
          <div style="background:#EDF7FF;border:1px solid #1565C0;border-radius:8px;padding:12px;margin:16px 0;">
            <p style="font-size:11px;color:#333;margin:0 0 4px;font-weight:bold;">CUFE (Código Único de Factura Electrónica):</p>
            <p style="font-size:10px;color:#1565C0;word-break:break-all;margin:0;">${cufe}</p>
          </div>
          <p style="font-size:12px;color:#666;">Valide su factura en <a href="https://catalogo-vpfe.dian.gov.co">dian.gov.co</a></p>
        </div>
      `
    });

    res.json({ ok: true });
  } catch (err) {
    console.error('[/reenviar-email]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── Set de pruebas DIAN ───────────────────────────────────────────────
app.post('/set-pruebas', async (req, res) => {
  try {
    const { emisor } = req.body;
    if (!emisor?.nit) return res.status(400).json({ error: 'Falta emisor.nit' });

    const resultados = [];

    // Factura 1 — Consumidor Final
    const f1 = await emitirFactura({
      emisor,
      receptor: { tipoDocumento: 'CF', documento: '222222222', nombre: 'Consumidor Final', correo: '' },
      factura: {
        numero: 'TEST001', fecha: new Date().toISOString().split('T')[0], hora: '12:00:00',
        total: 15000, totalBase: 13889, totalImpuestos: 1111, metodoPago: 'Efectivo',
        items: [{ nombre: 'Almuerzo ejecutivo', cantidad: 1, precioUnitario: 15000, total: 15000, iva: 8, base: 13889 }],
        ivaResumen: { '8': { base: 13889, impuesto: 1111, tasa: 8 } }
      }
    });
    resultados.push({ doc: 'Factura CF', ...f1 });

    // Factura 2 — Con NIT
    const f2 = await emitirFactura({
      emisor,
      receptor: { tipoDocumento: 'NIT', documento: '900123456', nombre: 'Empresa de Prueba S.A.S.', correo: 'prueba@empresa.com' },
      factura: {
        numero: 'TEST002', fecha: new Date().toISOString().split('T')[0], hora: '12:05:00',
        total: 35000, totalBase: 32407, totalImpuestos: 2593, metodoPago: 'Tarjeta',
        items: [{ nombre: 'Menú ejecutivo', cantidad: 2, precioUnitario: 17500, total: 35000, iva: 8, base: 16204 }],
        ivaResumen: { '8': { base: 32407, impuesto: 2593, tasa: 8 } }
      }
    });
    resultados.push({ doc: 'Factura NIT', ...f2 });

    console.log('[/set-pruebas] Resultados:', resultados.map(r => r.doc + ' → ' + r.estado).join(', '));
    res.json({ ok: true, resultados });

  } catch (err) {
    console.error('[/set-pruebas]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── Inicio ────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  const certInfo = process.env.CERT_BASE64 ? 'CERT_BASE64 ✅' : (process.env.CERT_PATH || '⚠️ NO CONFIGURADO');
  console.log(`\n✅ Backend FE Helechos · Puerto ${PORT}`);
  console.log(`   Ambiente: ${process.env.DIAN_AMBIENTE === 'produccion' ? '🟢 PRODUCCIÓN' : '🟡 PRUEBAS'}`);
  console.log(`   Certificado: ${certInfo}\n`);
});

