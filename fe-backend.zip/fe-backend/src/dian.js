/**
 * dian.js — Módulo de integración con la DIAN
 *
 * Flujo:
 *  1. construirXML()      → genera el XML UBL 2.1 de la factura
 *  2. calcularCUFE()      → calcula el código único (SHA-384)
 *  3. firmarXML()         → firma con XAdES-EPES usando el certificado .p12
 *  4. enviarSOAP()        → envía al Web Service de la DIAN
 *  5. parsearRespuesta()  → extrae el CUFE y el estado
 */

const forge    = require('node-forge');
const { create } = require('xmlbuilder2');
const axios    = require('axios');
const crypto   = require('crypto');
const fs       = require('fs');
const path     = require('path');

// ── URLs DIAN ─────────────────────────────────────────────────────────
const DIAN_URL = {
  pruebas:    'https://vpfe-hab.dian.gov.co/WcfDianCustomerServices.svc',
  produccion: 'https://vpfe.dian.gov.co/WcfDianCustomerServices.svc',
};

function getDianUrl() {
  return process.env.DIAN_AMBIENTE === 'produccion'
    ? DIAN_URL.produccion
    : DIAN_URL.pruebas;
}

// ── Leer certificado .p12 ─────────────────────────────────────────────
function leerCertificado() {
  const certPath = process.env.CERT_PATH;
  const certPass = process.env.CERT_PASSWORD || '';

  if (!certPath || !fs.existsSync(certPath)) {
    throw new Error(
      'Certificado no encontrado. Configura CERT_PATH en .env apuntando al archivo .p12'
    );
  }

  const p12Der  = fs.readFileSync(certPath);
  const p12Asn1 = forge.asn1.fromDer(p12Der.toString('binary'));
  const p12     = forge.pkcs12.pkcs12FromAsn1(p12Asn1, certPass);

  // Extraer llave privada y certificado
  let privateKey = null, certificate = null;

  for (const safeContent of p12.safeContents) {
    for (const safeBag of safeContent.safeBags) {
      if (safeBag.type === forge.pki.oids.pkcs8ShroudedKeyBag) {
        privateKey = safeBag.key;
      } else if (safeBag.type === forge.pki.oids.certBag) {
        certificate = safeBag.cert;
      }
    }
  }

  if (!privateKey || !certificate) {
    throw new Error('No se pudo extraer la llave privada o el certificado del archivo .p12');
  }

  return { privateKey, certificate };
}

// ── Calcular CUFE (SHA-384) ───────────────────────────────────────────
// Fórmula DIAN: SHA384(NumFac+FecFac+HorFac+ValFac+CodImp1+ValImp1+
//               CodImp2+ValImp2+CodImp3+ValImp3+ValTot+NitOFE+NumAdq+
//               ClTec+TipoAmb)
function calcularCUFE(f, emisor, ambiente) {
  const tipoAmb = ambiente === 'produccion' ? '1' : '2';
  const valFac  = f.totalBase.toFixed(2);
  const valImp1 = f.totalImpuestos.toFixed(2); // Impoconsumo 8%
  const valTot  = f.total.toFixed(2);

  // ClTec = clave técnica (la que da la DIAN al habilitar)
  const claveTecnica = process.env.DIAN_CLAVE_TECNICA || '';

  const cadena = [
    f.numero,
    f.fecha + 'T' + (f.hora || '00:00:00') + '-05:00',
    valFac,
    '03',   // Código impuesto 1: Impoconsumo
    valImp1,
    '01',   // Código impuesto 2: IVA (0 si no aplica)
    '0.00',
    '04',   // Código impuesto 3: ICA (0 si no aplica)
    '0.00',
    valTot,
    emisor.nit.replace(/-/g, '').replace(/\D/g, ''), // Solo dígitos
    '222222222', // NIT adquiriente (consumidor final si no tiene)
    claveTecnica,
    tipoAmb
  ].join('');

  return crypto.createHash('sha384').update(cadena, 'utf8').digest('hex');
}

// ── Construir XML UBL 2.1 ─────────────────────────────────────────────
function construirXML(payload, cufe) {
  const { emisor, receptor, factura } = payload;
  const ahora = new Date();
  const fechaEmision = ahora.toISOString().split('T')[0];
  const horaEmision  = ahora.toISOString().split('T')[1].substring(0, 8) + '-05:00';
  const ambiente     = process.env.DIAN_AMBIENTE === 'produccion' ? '1' : '2';

  const nitLimpio = emisor.nit.replace(/-/g, '').replace(/\D/g, '');
  const nitDV     = emisor.nit.includes('-') ? emisor.nit.split('-')[1] : '0';

  // Construir líneas de items
  const invoiceLines = factura.items.map((item, i) => ({
    'cbc:ID': String(i + 1),
    'cbc:InvoicedQuantity': {
      '@unitCode': 'EA',
      '#': String(item.cantidad)
    },
    'cbc:LineExtensionAmount': {
      '@currencyID': 'COP',
      '#': item.base.toFixed(2)
    },
    'cac:TaxTotal': {
      'cbc:TaxAmount': {
        '@currencyID': 'COP',
        '#': (item.total - item.base).toFixed(2)
      },
      'cac:TaxSubtotal': {
        'cbc:TaxableAmount': { '@currencyID': 'COP', '#': item.base.toFixed(2) },
        'cbc:TaxAmount':     { '@currencyID': 'COP', '#': (item.total - item.base).toFixed(2) },
        'cac:TaxCategory': {
          'cbc:Percent':       String(item.iva),
          'cac:TaxScheme': {
            'cbc:ID':   item.iva === 8 ? '03' : '01',  // 03=Impoconsumo 01=IVA
            'cbc:Name': item.iva === 8 ? 'INC' : 'IVA'
          }
        }
      }
    },
    'cac:Item': {
      'cbc:Description': item.nombre
    },
    'cac:Price': {
      'cbc:PriceAmount': {
        '@currencyID': 'COP',
        '#': item.base.toFixed(2)
      },
      'cbc:BaseQuantity': { '@unitCode': 'EA', '#': String(item.cantidad) }
    }
  }));

  const xmlObj = {
    'fe:Invoice': {
      '@xmlns:fe':          'http://www.dian.gov.co/contratos/facturaelectronica/v1',
      '@xmlns:cac':         'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2',
      '@xmlns:cbc':         'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2',
      '@xmlns:ext':         'urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2',
      '@xmlns:sts':         'http://www.dian.gov.co/contratos/facturaelectronica/v1/Structures',
      '@xmlns:xades':       'http://uri.etsi.org/01903/v1.3.2#',
      '@xmlns:xades141':    'http://uri.etsi.org/01903/v1.4.1#',
      '@xmlns:ds':          'http://www.w3.org/2000/09/xmldsig#',

      // Extensión para firma (placeholder — se reemplaza en firmarXML)
      'ext:UBLExtensions': {
        'ext:UBLExtension': {
          'ext:ExtensionContent': { '#': '' }
        }
      },

      'cbc:UBLVersionID':     '2.1',
      'cbc:CustomizationID':  '10',
      'cbc:ProfileID':        'DIAN 2.1',
      'cbc:ProfileExecutionID': ambiente,
      'cbc:ID':               (emisor.prefijo || 'FE') + factura.numero,
      'cbc:UUID': {
        '@schemeID': ambiente,
        '@schemeName': 'CUFE-SHA384',
        '#': cufe
      },
      'cbc:IssueDate':  fechaEmision,
      'cbc:IssueTime':  horaEmision,
      'cbc:InvoiceTypeCode':  {
        '@listAgencyID': 'CO',
        '@listAgencyName': 'No oficial',
        '@listSchemeURI': 'http://www.dian.gov.co/micrositios/payroll/docs/Anexo_Tecnico_Resolucion_0001_de_2018.pdf',
        '#': '01'
      },
      'cbc:Note':             { '@languageID': 'es', '#': 'Factura electrónica de venta' },
      'cbc:DocumentCurrencyCode': 'COP',
      'cbc:LineCountNumeric': String(factura.items.length),

      // Resolución DIAN
      'cac:InvoicePeriod': {
        'cbc:StartDate': emisor.fechaResolucion || fechaEmision,
        'cbc:EndDate':   fechaEmision
      },
      'cac:OrderReference': {
        'cbc:ID': factura.numero
      },
      'cac:BillingReference': {
        'cac:InvoiceDocumentReference': {
          'cbc:ID':   (emisor.prefijo || 'FE') + factura.numero,
          'cbc:UUID': { '@schemeID': ambiente, '@schemeName': 'CUFE-SHA384', '#': cufe },
          'cbc:IssueDate': fechaEmision
        }
      },

      // Proveedor (emisor)
      'cac:AccountingSupplierParty': {
        'cbc:AdditionalAccountID': '1', // 1=Persona jurídica
        'cac:Party': {
          'cac:PartyName':   { 'cbc:Name': emisor.nombre },
          'cac:PhysicalLocation': {
            'cac:Address': {
              'cbc:ID':              emisor.codigoCiudad || '11001',
              'cbc:CityName':        emisor.ciudad || 'Bogotá',
              'cbc:CountrySubentity': emisor.departamento || 'Cundinamarca',
              'cbc:CountrySubentityCode': '11',
              'cac:Country': { 'cbc:IdentificationCode': 'CO', 'cbc:Name': { '@languageID': 'es', '#': 'Colombia' } }
            }
          },
          'cac:PartyTaxScheme': {
            'cbc:RegistrationName': emisor.nombre,
            'cbc:CompanyID': {
              '@schemeAgencyID':   '195',
              '@schemeAgencyName': 'CO, DIAN (Dirección de Impuestos y Aduanas Nacionales)',
              '@schemeID':         nitDV,
              '@schemeName':       '31', // 31=NIT
              '#': nitLimpio
            },
            'cbc:TaxLevelCode':   { '@listName': 'No aplica', '#': 'O-99' },
            'cac:TaxScheme':      { 'cbc:ID': 'ZZ', 'cbc:Name': 'No aplica' }
          },
          'cac:PartyLegalEntity': {
            'cbc:RegistrationName': emisor.nombre,
            'cbc:CompanyID': {
              '@schemeAgencyID':   '195',
              '@schemeAgencyName': 'CO, DIAN (Dirección de Impuestos y Aduanas Nacionales)',
              '@schemeID':         nitDV,
              '@schemeName':       '31',
              '#': nitLimpio
            }
          },
          'cac:Contact': { 'cbc:ElectronicMail': process.env.EMISOR_EMAIL || '' }
        }
      },

      // Cliente (receptor)
      'cac:AccountingCustomerParty': {
        'cbc:AdditionalAccountID': '1',
        'cac:Party': {
          'cac:PartyName':   { 'cbc:Name': receptor.nombre || 'Consumidor Final' },
          'cac:PhysicalLocation': {
            'cac:Address': {
              'cbc:ID':   '11001',
              'cbc:CityName': 'Bogotá',
              'cbc:CountrySubentity': 'Cundinamarca',
              'cbc:CountrySubentityCode': '11',
              'cac:Country': { 'cbc:IdentificationCode': 'CO', 'cbc:Name': { '@languageID': 'es', '#': 'Colombia' } }
            }
          },
          'cac:PartyTaxScheme': {
            'cbc:RegistrationName': receptor.nombre || 'Consumidor Final',
            'cbc:CompanyID': {
              '@schemeAgencyID':   '195',
              '@schemeAgencyName': 'CO, DIAN (Dirección de Impuestos y Aduanas Nacionales)',
              '@schemeID':         '0',
              '@schemeName':       receptor.tipoDocumento === 'NIT' ? '31' : '13', // 13=Cédula 31=NIT
              '#': receptor.documento || '222222222'
            },
            'cbc:TaxLevelCode': { '@listName': 'No aplica', '#': 'R-99-PN' },
            'cac:TaxScheme':    { 'cbc:ID': 'ZZ', 'cbc:Name': 'No aplica' }
          },
          'cac:PartyLegalEntity': {
            'cbc:RegistrationName': receptor.nombre || 'Consumidor Final',
            'cbc:CompanyID': {
              '@schemeAgencyID':   '195',
              '@schemeAgencyName': 'CO, DIAN (Dirección de Impuestos y Aduanas Nacionales)',
              '@schemeID':         '0',
              '@schemeName':       receptor.tipoDocumento === 'NIT' ? '31' : '13',
              '#': receptor.documento || '222222222'
            }
          },
          'cac:Contact': { 'cbc:ElectronicMail': receptor.correo || '' }
        }
      },

      // Método de pago
      'cac:PaymentMeans': {
        'cbc:ID':             '1',  // 1=Contado
        'cbc:PaymentMeansCode': '10', // 10=Efectivo 42=Crédito
        'cbc:PaymentDueDate': fechaEmision
      },

      // Totales de impuestos
      'cac:TaxTotal': {
        'cbc:TaxAmount': { '@currencyID': 'COP', '#': factura.totalImpuestos.toFixed(2) },
        'cac:TaxSubtotal': {
          'cbc:TaxableAmount': { '@currencyID': 'COP', '#': factura.totalBase.toFixed(2) },
          'cbc:TaxAmount':     { '@currencyID': 'COP', '#': factura.totalImpuestos.toFixed(2) },
          'cac:TaxCategory': {
            'cbc:Percent':   '8.00',
            'cac:TaxScheme': { 'cbc:ID': '03', 'cbc:Name': 'INC' }
          }
        }
      },

      // Totales generales
      'cac:LegalMonetaryTotal': {
        'cbc:LineExtensionAmount': { '@currencyID': 'COP', '#': factura.totalBase.toFixed(2) },
        'cbc:TaxExclusiveAmount':  { '@currencyID': 'COP', '#': factura.totalBase.toFixed(2) },
        'cbc:TaxInclusiveAmount':  { '@currencyID': 'COP', '#': factura.total.toFixed(2) },
        'cbc:ChargeTotalAmount':   { '@currencyID': 'COP', '#': '0.00' },
        'cbc:PayableAmount':       { '@currencyID': 'COP', '#': factura.total.toFixed(2) }
      },

      // Líneas de items
      'cac:InvoiceLine': invoiceLines
    }
  };

  return create({ version: '1.0', encoding: 'UTF-8' }, xmlObj).end({ prettyPrint: false });
}

// ── Firmar XML con XAdES-EPES ─────────────────────────────────────────
function firmarXML(xmlString, privateKey, certificate) {
  // Serializar cert en base64
  const certDer    = forge.asn1.toDer(forge.pki.certificateToAsn1(certificate)).getBytes();
  const certBase64 = Buffer.from(certDer, 'binary').toString('base64');

  // Calcular DigestValue del certificado (SHA-1 para XAdES)
  const certDigest = forge.util.encode64(
    forge.md.sha1.create().update(certDer).digest().getBytes()
  );

  const signatureId   = 'sig-' + Date.now();
  const signedPropsId = signatureId + '-sp';
  const now           = new Date().toISOString();

  // Construir SignedProperties
  const signedPropsXml = `<xades:SignedProperties xmlns:xades="http://uri.etsi.org/01903/v1.3.2#" Id="${signedPropsId}">
    <xades:SignedSignatureProperties>
      <xades:SigningTime>${now}</xades:SigningTime>
      <xades:SigningCertificate>
        <xades:Cert>
          <xades:CertDigest>
            <ds:DigestMethod xmlns:ds="http://www.w3.org/2000/09/xmldsig#" Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>
            <ds:DigestValue xmlns:ds="http://www.w3.org/2000/09/xmldsig#">${certDigest}</ds:DigestValue>
          </xades:CertDigest>
          <xades:IssuerSerial>
            <ds:X509IssuerName xmlns:ds="http://www.w3.org/2000/09/xmldsig#">${certificate.issuer.getField('CN')?.value || ''}</ds:X509IssuerName>
            <ds:X509SerialNumber xmlns:ds="http://www.w3.org/2000/09/xmldsig#">${certificate.serialNumber}</ds:X509SerialNumber>
          </xades:IssuerSerial>
        </xades:Cert>
      </xades:SigningCertificate>
    </xades:SignedSignatureProperties>
  </xades:SignedProperties>`;

  // Digest del SignedProperties (SHA-256 para XAdES-EPES)
  const spDigest = crypto.createHash('sha256').update(signedPropsXml, 'utf8').digest('base64');

  // Digest del documento (SignedInfo referencia al doc completo)
  const docDigest = crypto.createHash('sha256').update(xmlString, 'utf8').digest('base64');

  // Construir SignedInfo
  const signedInfo = `<ds:SignedInfo xmlns:ds="http://www.w3.org/2000/09/xmldsig#">
    <ds:CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>
    <ds:SignatureMethod Algorithm="http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"/>
    <ds:Reference Id="ref-doc" URI="">
      <ds:Transforms>
        <ds:Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/>
      </ds:Transforms>
      <ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>
      <ds:DigestValue>${docDigest}</ds:DigestValue>
    </ds:Reference>
    <ds:Reference Id="ref-sp" URI="#${signedPropsId}" Type="http://uri.etsi.org/01903#SignedProperties">
      <ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>
      <ds:DigestValue>${spDigest}</ds:DigestValue>
    </ds:Reference>
  </ds:SignedInfo>`;

  // Firmar SignedInfo con RSA-SHA256
  const md  = forge.md.sha256.create();
  md.update(signedInfo, 'utf8');
  const signatureBytes = privateKey.sign(md);
  const signatureValue = Buffer.from(signatureBytes, 'binary').toString('base64');

  // Bloque Signature completo
  const signatureBlock = `<ds:Signature xmlns:ds="http://www.w3.org/2000/09/xmldsig#" Id="${signatureId}">
  ${signedInfo}
  <ds:SignatureValue>${signatureValue}</ds:SignatureValue>
  <ds:KeyInfo>
    <ds:X509Data>
      <ds:X509Certificate>${certBase64}</ds:X509Certificate>
    </ds:X509Data>
  </ds:KeyInfo>
  <ds:Object>
    <xades:QualifyingProperties xmlns:xades="http://uri.etsi.org/01903/v1.3.2#" Target="#${signatureId}">
      ${signedPropsXml}
    </xades:QualifyingProperties>
  </ds:Object>
</ds:Signature>`;

  // Insertar dentro de ext:ExtensionContent
  return xmlString.replace(
    '<ext:ExtensionContent></ext:ExtensionContent>',
    `<ext:ExtensionContent>${signatureBlock}</ext:ExtensionContent>`
  );
}

// ── Comprimir y codificar en Base64 para el SOAP ──────────────────────
const zlib = require('zlib');

function comprimirBase64(xmlString) {
  const compressed = zlib.deflateRawSync(Buffer.from(xmlString, 'utf8'));
  return compressed.toString('base64');
}

// ── Construir sobre SOAP ──────────────────────────────────────────────
function construirSOAP(xmlBase64, nitEmisor, softwareId, softwarePin) {
  // HashSoftware = SHA384(softwareId + softwarePin + numero)
  const hashSoftware = crypto
    .createHash('sha384')
    .update(softwareId + softwarePin + 'FE001', 'utf8')
    .digest('hex');

  return `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
               xmlns:wcf="http://wcf.dian.colombia">
  <soap:Header></soap:Header>
  <soap:Body>
    <wcf:SendBillSync>
      <wcf:fileName>fv${nitEmisor}0000${Date.now()}.xml</wcf:fileName>
      <wcf:contentFile>${xmlBase64}</wcf:contentFile>
    </wcf:SendBillSync>
  </soap:Body>
</soap:Envelope>`;
}

// ── Enviar SOAP a la DIAN ─────────────────────────────────────────────
async function enviarSOAP(soapBody) {
  const url  = getDianUrl();
  const resp = await axios.post(url, soapBody, {
    headers: {
      'Content-Type': 'application/soap+xml; charset=utf-8',
      'SOAPAction':   'http://wcf.dian.colombia/IWcfDianCustomerServices/SendBillSync',
    },
    timeout: 30000,
    // En pruebas la DIAN puede tener cert auto-firmado
    ...(process.env.DIAN_AMBIENTE !== 'produccion' && {
      httpsAgent: new (require('https').Agent)({ rejectUnauthorized: false })
    })
  });
  return resp.data;
}

// ── Parsear respuesta SOAP de la DIAN ────────────────────────────────
const xml2js = require('xml2js');

async function parsearRespuesta(soapResponse) {
  const parsed = await xml2js.parseStringPromise(soapResponse, {
    explicitArray: false,
    tagNameProcessors: [xml2js.processors.stripPrefix]
  });

  // Navegar la estructura SOAP
  const body   = parsed?.Envelope?.Body;
  const result = body?.SendBillSyncResponse?.SendBillSyncResult
              || body?.['SendBillSyncResponse']?.['SendBillSyncResult'];

  if (!result) throw new Error('Respuesta DIAN inesperada: ' + JSON.stringify(parsed));

  const isValid  = result?.IsValid === 'true';
  const cufe     = result?.XmlDocumentKey || '';
  const errores  = result?.ErrorMessage?.string;

  return {
    cufe,
    estado: isValid ? 'ACEPTADA' : 'RECHAZADA',
    errores: errores ? (Array.isArray(errores) ? errores : [errores]) : [],
    respuestaCompleta: result
  };
}

// ── Función principal: emitir factura ────────────────────────────────
async function emitirFactura(payload) {
  const { emisor, receptor, factura } = payload;
  const ambiente = process.env.DIAN_AMBIENTE || 'pruebas';

  // 1. Calcular CUFE
  const cufe = calcularCUFE(factura, emisor, ambiente);

  // 2. Construir XML UBL 2.1
  const xmlString = construirXML(payload, cufe);

  // 3. Leer certificado y firmar
  const { privateKey, certificate } = leerCertificado();
  const xmlFirmado = firmarXML(xmlString, privateKey, certificate);

  // 4. Comprimir y codificar
  const xmlBase64 = comprimirBase64(xmlFirmado);

  // 5. Construir y enviar SOAP
  const nitLimpio  = emisor.nit.replace(/-/g, '').replace(/\D/g, '');
  const softwareId = process.env.DIAN_SOFTWARE_ID  || '';
  const softwarePin = process.env.DIAN_SOFTWARE_PIN || '';
  const soapBody   = construirSOAP(xmlBase64, nitLimpio, softwareId, softwarePin);
  const soapResp   = await enviarSOAP(soapBody);

  // 6. Parsear respuesta
  const resultado = await parsearRespuesta(soapResp);

  console.log(`[FE] Factura ${factura.numero} → ${resultado.estado} | CUFE: ${resultado.cufe?.substring(0, 20)}...`);

  if (resultado.errores.length > 0) {
    console.warn('[FE] Errores DIAN:', resultado.errores);
  }

  return {
    cufe:   resultado.cufe || cufe, // Si la DIAN no devuelve CUFE, usar el calculado
    estado: resultado.estado,
    errores: resultado.errores,
    xml:    xmlFirmado,
  };
}

// ── Consultar estado ──────────────────────────────────────────────────
async function consultarEstado(cufe) {
  const soapBody = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
               xmlns:wcf="http://wcf.dian.colombia">
  <soap:Body>
    <wcf:GetStatusZip>
      <wcf:trackId>${cufe}</wcf:trackId>
    </wcf:GetStatusZip>
  </soap:Body>
</soap:Envelope>`;

  const respuesta = await axios.post(getDianUrl(), soapBody, {
    headers: { 'Content-Type': 'application/soap+xml; charset=utf-8' },
    timeout: 15000,
    ...(process.env.DIAN_AMBIENTE !== 'produccion' && {
      httpsAgent: new (require('https').Agent)({ rejectUnauthorized: false })
    })
  });

  return { cufe, respuesta: respuesta.data };
}

// ── Nota crédito ──────────────────────────────────────────────────────
// ── Nota Crédito (InvoiceTypeCode 91) ────────────────────────────────
async function emitirNotaCredito(payload) {
  const { emisor, receptor, facturaReferencia, motivo, total, items } = payload;
  const ambiente = process.env.DIAN_AMBIENTE || 'pruebas';
  const ahora    = new Date();
  const fecha    = ahora.toISOString().split('T')[0];
  const hora     = ahora.toISOString().split('T')[1].substring(0, 8) + '-05:00';
  const nitLimpio = emisor.nit.replace(/-/g, '').replace(/\D/g, '');

  // Construir XML nota crédito UBL 2.1
  const xmlObj = {
    'fe:CreditNote': {
      '@xmlns:fe':   'http://www.dian.gov.co/contratos/facturaelectronica/v1',
      '@xmlns:cac':  'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2',
      '@xmlns:cbc':  'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2',
      '@xmlns:ext':  'urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2',
      'ext:UBLExtensions': { 'ext:UBLExtension': { 'ext:ExtensionContent': { '#': '' } } },
      'cbc:UBLVersionID':       '2.1',
      'cbc:CustomizationID':    '22',
      'cbc:ProfileID':          'DIAN 2.1',
      'cbc:ProfileExecutionID': ambiente === 'produccion' ? '1' : '2',
      'cbc:ID':                 (emisor.prefijo || 'NC') + '001',
      'cbc:IssueDate':          fecha,
      'cbc:IssueTime':          hora,
      'cbc:Note':               { '@languageID': 'es', '#': motivo || 'Anulación de factura' },
      'cbc:DocumentCurrencyCode': 'COP',
      'cbc:LineCountNumeric':   String((items || []).length || 1),
      // Referencia a la factura original
      'cac:DiscrepancyResponse': {
        'cbc:ReferenceID':   facturaReferencia.numero,
        'cbc:ResponseCode':  '2', // 2 = Anulación
        'cbc:Description':   motivo || 'Anulación de factura electrónica'
      },
      'cac:BillingReference': {
        'cac:InvoiceDocumentReference': {
          'cbc:ID':        facturaReferencia.numero,
          'cbc:UUID':      { '@schemeID': ambiente==='produccion'?'1':'2', '@schemeName': 'CUFE-SHA384', '#': facturaReferencia.cufe },
          'cbc:IssueDate': facturaReferencia.fecha || fecha
        }
      },
      'cac:AccountingSupplierParty': {
        'cbc:AdditionalAccountID': '1',
        'cac:Party': {
          'cac:PartyName': { 'cbc:Name': emisor.nombre || '' },
          'cac:PartyTaxScheme': {
            'cbc:RegistrationName': emisor.nombre || '',
            'cbc:CompanyID': { '@schemeAgencyID':'195', '@schemeAgencyName':'CO, DIAN', '@schemeID':'0', '@schemeName':'31', '#': nitLimpio },
            'cbc:TaxLevelCode': { '@listName': 'No aplica', '#': 'O-99' },
            'cac:TaxScheme': { 'cbc:ID': 'ZZ', 'cbc:Name': 'No aplica' }
          },
          'cac:PartyLegalEntity': {
            'cbc:RegistrationName': emisor.nombre || '',
            'cbc:CompanyID': { '@schemeAgencyID':'195', '@schemeAgencyName':'CO, DIAN', '@schemeID':'0', '@schemeName':'31', '#': nitLimpio }
          }
        }
      },
      'cac:AccountingCustomerParty': {
        'cbc:AdditionalAccountID': '1',
        'cac:Party': {
          'cac:PartyName': { 'cbc:Name': receptor.nombre || 'Consumidor Final' },
          'cac:PartyTaxScheme': {
            'cbc:RegistrationName': receptor.nombre || 'Consumidor Final',
            'cbc:CompanyID': { '@schemeAgencyID':'195', '@schemeAgencyName':'CO, DIAN', '@schemeID':'0', '@schemeName': receptor.tipoDocumento==='NIT'?'31':'13', '#': receptor.documento || '222222222' },
            'cbc:TaxLevelCode': { '@listName': 'No aplica', '#': 'R-99-PN' },
            'cac:TaxScheme': { 'cbc:ID': 'ZZ', 'cbc:Name': 'No aplica' }
          },
          'cac:PartyLegalEntity': {
            'cbc:RegistrationName': receptor.nombre || 'Consumidor Final',
            'cbc:CompanyID': { '@schemeAgencyID':'195', '@schemeAgencyName':'CO, DIAN', '@schemeID':'0', '@schemeName': receptor.tipoDocumento==='NIT'?'31':'13', '#': receptor.documento || '222222222' }
          },
          'cac:Contact': { 'cbc:ElectronicMail': receptor.correo || '' }
        }
      },
      'cac:PaymentMeans': { 'cbc:ID': '1', 'cbc:PaymentMeansCode': '10', 'cbc:PaymentDueDate': fecha },
      'cac:TaxTotal': {
        'cbc:TaxAmount': { '@currencyID': 'COP', '#': '0.00' },
        'cac:TaxSubtotal': {
          'cbc:TaxableAmount': { '@currencyID': 'COP', '#': String((total || 0).toFixed(2)) },
          'cbc:TaxAmount':     { '@currencyID': 'COP', '#': '0.00' },
          'cac:TaxCategory': { 'cbc:Percent': '0', 'cac:TaxScheme': { 'cbc:ID': '03', 'cbc:Name': 'INC' } }
        }
      },
      'cac:LegalMonetaryTotal': {
        'cbc:LineExtensionAmount': { '@currencyID': 'COP', '#': String((total || 0).toFixed(2)) },
        'cbc:TaxExclusiveAmount':  { '@currencyID': 'COP', '#': String((total || 0).toFixed(2)) },
        'cbc:TaxInclusiveAmount':  { '@currencyID': 'COP', '#': String((total || 0).toFixed(2)) },
        'cbc:PayableAmount':       { '@currencyID': 'COP', '#': String((total || 0).toFixed(2)) }
      },
      'cac:CreditNoteLine': [{
        'cbc:ID': '1',
        'cbc:CreditedQuantity': { '@unitCode': 'EA', '#': '1' },
        'cbc:LineExtensionAmount': { '@currencyID': 'COP', '#': String((total || 0).toFixed(2)) },
        'cac:Item': { 'cbc:Description': motivo || 'Anulación' },
        'cac:Price': { 'cbc:PriceAmount': { '@currencyID': 'COP', '#': String((total || 0).toFixed(2)) }, 'cbc:BaseQuantity': { '@unitCode': 'EA', '#': '1' } }
      }]
    }
  };

  const xmlString  = create({ version: '1.0', encoding: 'UTF-8' }, xmlObj).end({ prettyPrint: false });
  const { privateKey, certificate } = leerCertificado();
  const xmlFirmado = firmarXML(xmlString, privateKey, certificate);
  const xmlBase64  = comprimirBase64(xmlFirmado);
  const softwareId  = process.env.DIAN_SOFTWARE_ID  || '';
  const softwarePin = process.env.DIAN_SOFTWARE_PIN || '';
  const soapBody   = construirSOAP(xmlBase64, nitLimpio, softwareId, softwarePin);
  const soapResp   = await enviarSOAP(soapBody);
  const resultado  = await parsearRespuesta(soapResp);
  console.log(`[NC] → ${resultado.estado} | CUFE: ${resultado.cufe?.substring(0,20)}...`);
  return { cufe: resultado.cufe, estado: resultado.estado, errores: resultado.errores };
}

// ── Nota Débito (InvoiceTypeCode 92) ─────────────────────────────────
async function emitirNotaDebito(payload) {
  const { emisor, receptor, facturaReferencia, motivo, valor, base, impuesto, items } = payload;
  const ambiente  = process.env.DIAN_AMBIENTE || 'pruebas';
  const ahora     = new Date();
  const fecha     = ahora.toISOString().split('T')[0];
  const hora      = ahora.toISOString().split('T')[1].substring(0, 8) + '-05:00';
  const nitLimpio = emisor.nit.replace(/-/g, '').replace(/\D/g, '');
  const baseStr   = String((base   || valor || 0).toFixed(2));
  const impStr    = String((impuesto || 0).toFixed(2));
  const totalStr  = String((valor  || 0).toFixed(2));

  const xmlObj = {
    'fe:DebitNote': {
      '@xmlns:fe':   'http://www.dian.gov.co/contratos/facturaelectronica/v1',
      '@xmlns:cac':  'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2',
      '@xmlns:cbc':  'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2',
      '@xmlns:ext':  'urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2',
      'ext:UBLExtensions': { 'ext:UBLExtension': { 'ext:ExtensionContent': { '#': '' } } },
      'cbc:UBLVersionID':       '2.1',
      'cbc:CustomizationID':    '22',
      'cbc:ProfileID':          'DIAN 2.1',
      'cbc:ProfileExecutionID': ambiente === 'produccion' ? '1' : '2',
      'cbc:ID':                 (emisor.prefijo || 'ND') + '001',
      'cbc:IssueDate':          fecha,
      'cbc:IssueTime':          hora,
      'cbc:Note':               { '@languageID': 'es', '#': motivo?.descripcion || 'Cargo adicional' },
      'cbc:DocumentCurrencyCode': 'COP',
      'cbc:LineCountNumeric':   String((items || []).length || 1),
      'cac:DiscrepancyResponse': {
        'cbc:ReferenceID':  facturaReferencia.numero,
        'cbc:ResponseCode': motivo?.codigo || '2',
        'cbc:Description':  motivo?.descripcion || 'Cargo adicional'
      },
      'cac:BillingReference': {
        'cac:InvoiceDocumentReference': {
          'cbc:ID':        facturaReferencia.numero,
          'cbc:UUID':      { '@schemeID': ambiente==='produccion'?'1':'2', '@schemeName': 'CUFE-SHA384', '#': facturaReferencia.cufe },
          'cbc:IssueDate': facturaReferencia.fecha || fecha
        }
      },
      'cac:AccountingSupplierParty': {
        'cbc:AdditionalAccountID': '1',
        'cac:Party': {
          'cac:PartyName': { 'cbc:Name': emisor.nombre || '' },
          'cac:PartyTaxScheme': {
            'cbc:RegistrationName': emisor.nombre || '',
            'cbc:CompanyID': { '@schemeAgencyID':'195', '@schemeAgencyName':'CO, DIAN', '@schemeID':'0', '@schemeName':'31', '#': nitLimpio },
            'cbc:TaxLevelCode': { '@listName': 'No aplica', '#': 'O-99' },
            'cac:TaxScheme': { 'cbc:ID': 'ZZ', 'cbc:Name': 'No aplica' }
          },
          'cac:PartyLegalEntity': {
            'cbc:RegistrationName': emisor.nombre || '',
            'cbc:CompanyID': { '@schemeAgencyID':'195', '@schemeAgencyName':'CO, DIAN', '@schemeID':'0', '@schemeName':'31', '#': nitLimpio }
          }
        }
      },
      'cac:AccountingCustomerParty': {
        'cbc:AdditionalAccountID': '1',
        'cac:Party': {
          'cac:PartyName': { 'cbc:Name': receptor.nombre || 'Consumidor Final' },
          'cac:PartyTaxScheme': {
            'cbc:RegistrationName': receptor.nombre || 'Consumidor Final',
            'cbc:CompanyID': { '@schemeAgencyID':'195', '@schemeAgencyName':'CO, DIAN', '@schemeID':'0', '@schemeName': receptor.tipoDocumento==='NIT'?'31':'13', '#': receptor.documento || '222222222' },
            'cbc:TaxLevelCode': { '@listName': 'No aplica', '#': 'R-99-PN' },
            'cac:TaxScheme': { 'cbc:ID': 'ZZ', 'cbc:Name': 'No aplica' }
          },
          'cac:PartyLegalEntity': {
            'cbc:RegistrationName': receptor.nombre || 'Consumidor Final',
            'cbc:CompanyID': { '@schemeAgencyID':'195', '@schemeAgencyName':'CO, DIAN', '@schemeID':'0', '@schemeName': receptor.tipoDocumento==='NIT'?'31':'13', '#': receptor.documento || '222222222' }
          },
          'cac:Contact': { 'cbc:ElectronicMail': receptor.correo || '' }
        }
      },
      'cac:PaymentMeans': { 'cbc:ID': '1', 'cbc:PaymentMeansCode': '10', 'cbc:PaymentDueDate': fecha },
      'cac:TaxTotal': {
        'cbc:TaxAmount': { '@currencyID': 'COP', '#': impStr },
        'cac:TaxSubtotal': {
          'cbc:TaxableAmount': { '@currencyID': 'COP', '#': baseStr },
          'cbc:TaxAmount':     { '@currencyID': 'COP', '#': impStr },
          'cac:TaxCategory': { 'cbc:Percent': '8.00', 'cac:TaxScheme': { 'cbc:ID': '03', 'cbc:Name': 'INC' } }
        }
      },
      'cac:RequestedMonetaryTotal': {
        'cbc:LineExtensionAmount': { '@currencyID': 'COP', '#': baseStr },
        'cbc:TaxExclusiveAmount':  { '@currencyID': 'COP', '#': baseStr },
        'cbc:TaxInclusiveAmount':  { '@currencyID': 'COP', '#': totalStr },
        'cbc:PayableAmount':       { '@currencyID': 'COP', '#': totalStr }
      },
      'cac:DebitNoteLine': [{
        'cbc:ID': '1',
        'cbc:DebitedQuantity': { '@unitCode': 'EA', '#': '1' },
        'cbc:LineExtensionAmount': { '@currencyID': 'COP', '#': baseStr },
        'cac:TaxTotal': {
          'cbc:TaxAmount': { '@currencyID': 'COP', '#': impStr },
          'cac:TaxSubtotal': {
            'cbc:TaxableAmount': { '@currencyID': 'COP', '#': baseStr },
            'cbc:TaxAmount':     { '@currencyID': 'COP', '#': impStr },
            'cac:TaxCategory': { 'cbc:Percent': '8.00', 'cac:TaxScheme': { 'cbc:ID': '03', 'cbc:Name': 'INC' } }
          }
        },
        'cac:Item': { 'cbc:Description': motivo?.descripcion || 'Cargo adicional' },
        'cac:Price': { 'cbc:PriceAmount': { '@currencyID': 'COP', '#': baseStr }, 'cbc:BaseQuantity': { '@unitCode': 'EA', '#': '1' } }
      }]
    }
  };

  const xmlString  = create({ version: '1.0', encoding: 'UTF-8' }, xmlObj).end({ prettyPrint: false });
  const { privateKey, certificate } = leerCertificado();
  const xmlFirmado = firmarXML(xmlString, privateKey, certificate);
  const xmlBase64  = comprimirBase64(xmlFirmado);
  const softwareId  = process.env.DIAN_SOFTWARE_ID  || '';
  const softwarePin = process.env.DIAN_SOFTWARE_PIN || '';
  const soapBody   = construirSOAP(xmlBase64, nitLimpio, softwareId, softwarePin);
  const soapResp   = await enviarSOAP(soapBody);
  const resultado  = await parsearRespuesta(soapResp);
  console.log(`[ND] → ${resultado.estado} | CUFE: ${resultado.cufe?.substring(0,20)}...`);
  return { cufe: resultado.cufe, estado: resultado.estado, errores: resultado.errores };
}

module.exports = { emitirFactura, consultarEstado, emitirNotaCredito, emitirNotaDebito };
