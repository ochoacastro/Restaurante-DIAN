# 🧾 Backend Factura Electrónica — Los Helechos

Servidor Node.js que firma y envía facturas electrónicas a la DIAN de Colombia.

## Requisitos previos

1. Tener el **NIT** del restaurante
2. Haberse registrado en el **portal DIAN** como facturador electrónico (software propio)
3. Tener el **Software ID** y **Software PIN** que entrega la DIAN
4. Tener el archivo **certificado.p12** (comprado en Certicámara o GSE)

---

## Despliegue en Railway

### Paso 1 — Subir el código

```bash
# Instalar Railway CLI
npm install -g @railway/cli

# Login
railway login

# Crear proyecto nuevo
railway new

# Vincular y desplegar
railway up
```

### Paso 2 — Configurar variables de entorno en Railway

En el dashboard de Railway → tu proyecto → Variables, agrega:

| Variable | Valor |
|---|---|
| `DIAN_AMBIENTE` | `pruebas` (luego cambias a `produccion`) |
| `DIAN_SOFTWARE_ID` | El UUID que te dio la DIAN |
| `DIAN_SOFTWARE_PIN` | El PIN numérico de la DIAN |
| `DIAN_CLAVE_TECNICA` | La clave técnica de la DIAN |
| `CERT_PASSWORD` | Contraseña de tu archivo .p12 |
| `CERT_BASE64` | (ver paso 3) |
| `EMISOR_EMAIL` | Email del restaurante |

### Paso 3 — Subir el certificado .p12

El certificado NO va en el repositorio. En Railway se sube como variable en base64:

```bash
# En tu computador, convierte el .p12 a base64
base64 -i certificado.p12 | tr -d '\n'

# Copia el resultado y pégalo como variable CERT_BASE64 en Railway
```

Luego modifica `src/dian.js` para leer el certificado desde la variable:

```javascript
// Reemplaza esta línea en leerCertificado():
const p12Der = fs.readFileSync(certPath);

// Por esto:
const p12Der = process.env.CERT_BASE64
  ? Buffer.from(process.env.CERT_BASE64, 'base64')
  : fs.readFileSync(certPath);
```

### Paso 4 — Verificar que funciona

```bash
# Reemplaza con tu URL de Railway
curl https://tu-app.railway.app/ping
```

Debes ver:
```json
{
  "ok": true,
  "servicio": "FE Helechos Backend",
  "ambiente": "PRUEBAS"
}
```

### Paso 5 — Configurar en el POS

En el POS (index.html) → Ajustes → **Factura Electrónica DIAN**:
- Pega la URL de Railway
- Llena NIT, prefijo, resolución y rango
- Haz clic en "Probar conexión"

---

## Endpoints

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/ping` | Verificar que el servidor está vivo |
| POST | `/emitir-factura` | Emitir una factura electrónica |
| GET | `/estado/:cufe` | Consultar estado de una FE por CUFE |
| POST | `/nota-credito` | Emitir nota crédito (anulación) |

---

## Set de pruebas DIAN

Antes de ir a producción, la DIAN exige un set de pruebas:

```bash
# Ejecuta desde el POS: emite estas facturas de prueba
# 1. Factura con receptor Consumidor Final
# 2. Factura con receptor con NIT
# 3. Nota crédito referenciando la factura 1
# 4. Nota débito
```

Cuando la DIAN apruebe el set → cambia `DIAN_AMBIENTE=produccion` en Railway.

---

## Estructura

```
fe-backend/
├── src/
│   ├── index.js     ← Servidor Express (endpoints)
│   └── dian.js      ← Lógica DIAN (XML, firma, SOAP)
├── certs/           ← Aquí va el .p12 (NO subir a git)
├── .env.example     ← Plantilla de variables
├── .gitignore
└── package.json
```
